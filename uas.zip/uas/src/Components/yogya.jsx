import React from 'react';
import '../Components/yogya.css'; // Adjust the file path to navigate to the correct directory

const Yogya = () => {
    return (
      <div className="map-container">
        <svg
          fill="#000000"
          version="1.1"
          id="Layer_1"
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="250%"
          height="auto"
          viewBox="0 0 300 150"
          enableBackground="new 0 0 260 82"
          xmlSpace="preserve"
        >
          <path
            id="jawa"
            fill="#56A232"
            d="M101.002,68.098l-1.014-3.303l-5.026-0.661l-5.403-0.944l-0.92,2.431l-8.471-0.213l-3.893-2.902l-6.535-0.401
            l-1.392-0.024l-3.705-0.707l-1.227,3.468l3.516,2.359l0.778,2.195l10.429,1.533l1.793-0.943l6.701,0.802l4.365,1.415l0.543,0.118
            l11.986-0.377l4.247,1.628l2.383-4.341l-6.229,0.094L101.002,68.098z"
          />
        </svg>
      </div>
    );
  };
  
  export default Yogya;
