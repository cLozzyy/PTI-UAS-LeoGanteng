import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom"; // Perhatikan penulisan Route dan Routes
import Home from './Pages/home'; // Pastikan penulisan path menuju home.jsx yang benar
import Yogya from './Components/yogya'; // Pastikan penulisan path menuju yogya.jsx yang benar

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/yogya" element={<Yogya />} /> {/* Perhatikan penulisan path untuk Yogya */}
      </Routes>
    </Router>
  );
};

export default App;
