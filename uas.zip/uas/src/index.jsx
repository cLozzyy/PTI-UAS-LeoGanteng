import React from 'react';
import ReactDOM from 'react-dom';
import App from './App'; // Sesuaikan path ini dengan struktur folder proyek Anda

ReactDOM.render(<App />, document.getElementById('root'));
